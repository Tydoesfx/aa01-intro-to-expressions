/*
Here's the prompt for this problem file:

Time to write your first program! Use `console.log` to print out a message.
Closely follow the syntax of the given `console.log` example.
*/

// Here is an example of using console.log to print: Hello World!:

console.log('Hello World!');

// Print out your own message using console.log below:

// Your code here
console.log('Hey my name is Tyson')