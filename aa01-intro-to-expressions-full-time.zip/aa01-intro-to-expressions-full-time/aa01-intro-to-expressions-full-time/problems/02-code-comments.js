/*
Use your newfound knowledge of comments to execute the prompts in this problem
file.
*/

/* 1. This will print 'Welcome to App Academy!'  */

console.log('Welcome to App Academy!');

/* Print more messages to the terminal using console.log */
console.log('My tree is green');
console.log('Hello world');
// 2. This is a single line comment.
// console.log('This is will not be printed to the terminal')
// Try adding your own single line comments: Hello My name is Tyson

/* 3.
This is a multi-line comment.
Try adding your own multi-line comments:
*/
// Your code here 
/* Hello my name 
is Tyson
*/